README for SA Tools.

To learn more about how to use these examples with SA Tools, try

    >> help anneal

or see the file

	satools/satools.pdf

or visit

	http://www.frostconcepts.com/software


Get the book:  http://www.frostconcepts.com/books/ebsa/

Copyright
 
        Richard Frost
        Frost Concepts
        P.O. Box 721508
        San Diego, CA 92172
 
Copyright (c) 2002, by Richard Frost and Frost Concepts.  All rights
reserved except where otherwise noted.  This software is offered on an
"AS IS" basis.  The copyright holder(s) provide no warranty, expressed
or implied, that the software will function properly or that it will be
free of errors.  This software may be freely copied and distributed for
research and educational purposes only, provided that the above
copyright notice appear in all copies.  A license is needed for
commercial sale or use, in whole or in part, from Frost Concepts.
Users of the software agree to acknowledge the copyright holder(s).


Simulated Annealing Tools Software.

  * Individual or group academic research (non-commercial gain) or Purchase Evaluation: 
    Freely distributed. 

  * Individual or departmental non-academic use without redistribution or "service bureau" application: 
    $400 for current version. Updates to current version at no additional cost. 

  * Unlimited commercial or "service bureau" use by individual or site: 
    $2000 for current version. Updates to current version at no additional cost. 

  Make payment to:
 
        Frost Concepts
        P.O. Box 721508
        San Diego, CA 92172

"Simulated Annealing Tools Software", "SA Tools", and "satools" are trademarks of Frost Concepts.


, and "satools" are trademarks of Frost Concepts.


