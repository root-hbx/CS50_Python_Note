For explanation of these toy examples, see

	P. Salamon, P. Sibani, and R. Frost.
	Facts, Conjectures, and Improvements for Simulated Annealing.
	SIAM Monographs on Mathematical Modeling and Computation.
	ISBN 0-89871-508-3.

	Chapter 2: Six Simulated Annealing Problems.

To learn more about how to use these examples with SA Tools, try

    >> help anneal

or see the file

	satools/satools.pdf

or visit

	http://www.frostconcepts.com/software
cepts.com/software
